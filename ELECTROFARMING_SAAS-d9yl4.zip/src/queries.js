import { HttpError } from 'wasp/server'

export const getUserCrops = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  return context.entities.Crop.findMany({
    where: { userId: args.userId }
  });
}

export const getCropSensorData = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }
  return context.entities.SensorData.findMany({
    where: { cropId: args.cropId },
    include: { crop: true }
  });
}

export const getForumThreads = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  return context.entities.ForumThread.findMany();
}

export const getResources = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  return context.entities.Resource.findMany();
}