import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery, useAction, getUserCrops, getCropSensorData, getForumThreads, getResources } from 'wasp/client/operations';

const AdminPanelPage = () => {
  const { data: crops, isLoading: cropsLoading, error: cropsError } = useQuery(getUserCrops);
  const { data: sensorData, isLoading: sensorDataLoading, error: sensorDataError } = useQuery(getCropSensorData);
  const { data: forumThreads, isLoading: forumThreadsLoading, error: forumThreadsError } = useQuery(getForumThreads);
  const { data: resources, isLoading: resourcesLoading, error: resourcesError } = useQuery(getResources);

  if (cropsLoading || sensorDataLoading || forumThreadsLoading || resourcesLoading) return 'Loading...';
  if (cropsError || sensorDataError || forumThreadsError || resourcesError) return 'Error: ' + (cropsError || sensorDataError || forumThreadsError || resourcesError);

  return (
    <div className='p-4'>
      <div>
        <h1>User Crops:</h1>
        {crops.map((crop) => (
          <div key={crop.id}>{crop.name}</div>
        ))}
      </div>
      <div>
        <h1>Sensor Data:</h1>
        {sensorData.map((data) => (
          <div key={data.id}>{data.moisture} - {data.temperature} - {data.nutrientLevel}</div>
        ))}
      </div>
      <div>
        <h1>Forum Threads:</h1>
        {forumThreads.map((thread) => (
          <div key={thread.id}>{thread.title}</div>
        ))}
      </div>
      <div>
        <h1>Resources:</h1>
        {resources.map((resource) => (
          <div key={resource.id}>{resource.title} - {resource.type}</div>
        ))}
      </div>
    </div>
  );
}

export default AdminPanelPage;