import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery, useAction, getUserCrops, createCrop } from 'wasp/client/operations';

const DashboardPage = () => {
  const { data: userCrops, isLoading, error } = useQuery(getUserCrops);
  const createCropFn = useAction(createCrop);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleCreateCrop = () => {
    createCropFn({ cropName: 'New Crop' });
  };

  return (
    <div className='p-4'>
      {userCrops.map((crop) => (
        <div key={crop.id} className='bg-gray-100 p-4 mb-4 rounded-lg'>
          <div>{crop.name}</div>
          <button
            onClick={handleCreateCrop}
            className='bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded ml-2'
          >
            Add Crop
          </button>
        </div>
      ))}
    </div>
  );
}

export default DashboardPage;