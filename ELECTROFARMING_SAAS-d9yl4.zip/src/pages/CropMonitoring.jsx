import React from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from 'wasp/client/operations';

const CropMonitoringPage = () => {
  const { cropId } = useParams();
  const { data: sensorData, isLoading, error } = useQuery(getCropSensorData, { cropId });

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  return (
    <div className='p-4'>
      <h1 className='text-2xl font-bold mb-4'>Crop Monitoring for Crop ID: {cropId}</h1>
      <div className='grid grid-cols-2 gap-4'>
        {sensorData.map((data) => (
          <div key={data.id} className='bg-white p-4 shadow-md rounded-md'>
            <h2 className='text-lg font-semibold mb-2'>Sensor Data</h2>
            <p>Moisture: {data.moisture}</p>
            <p>Temperature: {data.temperature}</p>
            <p>Nutrient Levels: {data.nutrientLevel}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default CropMonitoringPage;