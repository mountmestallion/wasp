import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery, useAction, getForumThreads, createForumThread } from 'wasp/client/operations';

const CommunityForumPage = () => {
  const { data: forumThreads, isLoading, error } = useQuery(getForumThreads);
  const createForumThreadFn = useAction(createForumThread);
  const [newThreadTitle, setNewThreadTitle] = useState('');
  const [newThreadDescription, setNewThreadDescription] = useState('');
  const [newThreadTags, setNewThreadTags] = useState('');

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleCreateForumThread = () => {
    createForumThreadFn({ title: newThreadTitle, content: newThreadDescription, tags: newThreadTags });
    setNewThreadTitle('');
    setNewThreadDescription('');
    setNewThreadTags('');
  };

  return (
    <div className='p-4'>
      <input type='text' placeholder='Title' className='px-1 py-2 border rounded text-lg mb-2' value={newThreadTitle} onChange={(e) => setNewThreadTitle(e.target.value)} />
      <textarea placeholder='Description' className='px-1 py-2 border rounded text-lg mb-2' value={newThreadDescription} onChange={(e) => setNewThreadDescription(e.target.value)}></textarea>
      <input type='text' placeholder='Tags' className='px-1 py-2 border rounded text-lg mb-2' value={newThreadTags} onChange={(e) => setNewThreadTags(e.target.value)} />
      <button onClick={handleCreateForumThread} className='bg-blue-500 hover:bg-blue-700 px-2 py-2 text-white font-bold rounded'>Post Question</button>
      <div>
        {forumThreads.map((thread) => (
          <div key={thread.id} className='bg-gray-100 p-4 mb-4 rounded-lg'>
            <div>{thread.title}</div>
            <div>Author: {thread.user.name}</div>
            <div>Date: {thread.createdAt}</div>
            <div>Replies: {thread.replies.length}</div>
            <Link to={`/forum/${thread.id}`} className='bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded mt-2'>View Thread</Link>
          </div>
        ))}
      </div>
    </div>
  );
}

export default CommunityForumPage;