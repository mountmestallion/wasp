import React from 'react';
import { useQuery, getResources } from 'wasp/client/operations';

const EducationalResourcesPage = () => {
  const { data: resources, isLoading, error } = useQuery(getResources);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  return (
    <div className='p-4'>
      <h1 className='text-2xl font-bold mb-4'>Featured Articles</h1>
      <div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4'>
        {resources.map((resource) => (
          <div key={resource.id} className='bg-white p-4 rounded-lg shadow-md'>
            <img src={resource.thumbnail} alt={resource.title} className='w-full h-48 object-cover mb-2 rounded' />
            <h2 className='text-lg font-semibold mb-2'>{resource.title}</h2>
            <p className='text-gray-600'>{resource.excerpt}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default EducationalResourcesPage;