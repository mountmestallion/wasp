import { HttpError } from 'wasp/server'

export const createCrop = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  return context.entities.Crop.create({
    data: {
      name: args.cropName,
      userId: context.user.id
    }
  });
}

export const createSensorData = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const crop = await context.entities.Crop.findUnique({
    where: { id: args.cropId }
  });
  if (crop.userId !== context.user.id) { throw new HttpError(403) };

  return context.entities.SensorData.create({
    data: {
      moisture: args.moisture,
      temperature: args.temperature,
      nutrientLevel: args.nutrientLevel,
      crop: { connect: { id: args.cropId } }
    }
  });
}

export const createForumThread = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };
  return context.entities.ForumThread.create({
    data: {
      title: args.title,
      content: args.content,
      userId: context.user.id
    }
  });
}

export const updateUserProfile = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const updatedUser = await context.entities.User.update({
    where: { id: args.userId },
    data: { name: args.name, email: args.email }
  });

  return updatedUser;
}